# Circuit Description

## Microcontroller: AT89C51

The AT89C51 is an 8051-family microcontroller with:
- 4 KB of on-chip Flash program memory
- 128 bytes of internal RAM
- Four 8-bit I/O ports (P0–P3)
- One 16-bit timer/counter (not used in this project)
- Operating voltage: 4.0–5.5 V

## Port Configuration

### Port 0 — LED output (Switch 1 count)

Port 0 pins P0.0 through P0.7 are configured as outputs.  
Each pin drives one common-cathode LED through a 330 Ω current-limiting resistor.

- **P0.0** → LED 1 (LSB — bit 0 of count1)  
- **P0.7** → LED 8 (MSB — bit 7 of count1)

> Port 0 is an open-drain port. A 10 kΩ pull-up resistor array connected to VCC is mandatory to allow the port to output a logic high and source LED current.

### Port 1 — LED output (Switch 2 count)

Port 1 pins P1.0 through P1.7 are configured as outputs.  
Same wiring as Port 0; no external pull-ups needed (Port 1 has internal pull-ups).

- **P1.0** → LED 9  (LSB — bit 0 of count2)  
- **P1.7** → LED 16 (MSB — bit 7 of count2)

### Port 2 — Switch inputs

- **P2.0** → Switch 1 (active-low; released = 1, pressed = 0)  
- **P2.1** → Switch 2 (active-low; released = 1, pressed = 0)

Initialising P2 to `0xFF` in firmware enables the internal quasi-bidirectional pull-ups, so no external pull-up resistors are needed on Port 2.

## Clock Circuit

A 11.0592 MHz crystal with two 22 pF load capacitors connects across XTAL1 and XTAL2.  
This frequency is chosen because it yields exact baud-rate divisors for UART use (not required here, but good practice).

Machine cycle period = 12 / 11,059,200 Hz ≈ **1.085 µs**

## Reset Circuit

- A 10 µF electrolytic capacitor (positive terminal to VCC, negative to RST)  
- A 10 kΩ resistor from RST to GND  

On power-up the capacitor charges through the resistor, holding RST high (active) for approximately 100 ms before the MCU begins executing code. This ensures all registers are in a known state.

## LED Current Calculation

Using 330 Ω resistors with VCC = 5 V and a typical LED forward voltage of 2.0 V:

```
I_LED = (5.0 V − 2.0 V) / 330 Ω ≈ 9 mA
```

This is within the AT89C51's maximum per-pin current rating of 10 mA (source) and keeps LEDs safely illuminated without stressing the port driver.
