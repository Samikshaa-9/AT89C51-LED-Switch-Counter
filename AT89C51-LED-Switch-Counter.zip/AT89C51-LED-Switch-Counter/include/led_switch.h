/**
 * @file    led_switch.h
 * @brief   Pin aliases and utility prototypes for the LED–Switch counter project.
 *
 * Centralising the pin definitions here means only this file needs editing
 * if the hardware layout ever changes.
 */

#ifndef LED_SWITCH_H
#define LED_SWITCH_H

#include <REGX51.H>

/* -----------------------------------------------------------------------
 * Switch pin aliases  (Port 2, active-low)
 * ----------------------------------------------------------------------- */
#define SW1   P2_0      /**< Switch 1 — increments Port 0 LED count */
#define SW2   P2_1      /**< Switch 2 — increments Port 1 LED count */

/* -----------------------------------------------------------------------
 * LED port aliases
 * ----------------------------------------------------------------------- */
#define LED_PORT0   P0  /**< 8 LEDs: LSB at P0.0, MSB at P0.7 */
#define LED_PORT1   P1  /**< 8 LEDs: LSB at P1.0, MSB at P1.7 */

/* -----------------------------------------------------------------------
 * Debounce / visibility delay
 *
 * At 11.0592 MHz the machine cycle is ~1.085 µs.
 * A loop count of 30 000 gives roughly 20–25 ms — sufficient to suppress
 * typical mechanical-switch bounce (< 10 ms).
 * ----------------------------------------------------------------------- */
#define DEBOUNCE_COUNT  30000U

/**
 * @brief Blocking software delay used for switch debounce.
 *
 * Call once after detecting a pressed state and again after release.
 * The compiler must NOT optimise away the loop; the volatile cast ensures
 * the counter variable is actually read each iteration even in optimised
 * builds.
 */
void debounce_delay(void);

#endif /* LED_SWITCH_H */
