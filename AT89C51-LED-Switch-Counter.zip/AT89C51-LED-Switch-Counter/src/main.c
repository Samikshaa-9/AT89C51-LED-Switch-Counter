/**
 * @file    main.c
 * @brief   Dual switch press counter with binary LED display on AT89C51
 *
 * Hardware configuration:
 *   - Port 0 (P0.0–P0.7) : 8 common-cathode LEDs — displays count of Switch 1 (P2.0)
 *   - Port 1 (P1.0–P1.7) : 8 common-cathode LEDs — displays count of Switch 2 (P2.1)
 *   - Port 2 (P2.0, P2.1): Active-low push-button inputs (internal pull-ups via 0xFF init)
 *
 * Operation:
 *   Each switch press increments its counter (0–255) and the new value is
 *   immediately reflected as an 8-bit binary pattern on the respective LED port.
 *   A software debounce delay prevents false multiple-counts on a single press.
 *
 * Toolchain : Keil µVision (C51 compiler)
 * Device    : AT89C51 (8051-family), 11.0592 MHz crystal
 */

#include <REGX51.H>
#include "led_switch.h"

/* -----------------------------------------------------------------------
 * Main entry point
 * ----------------------------------------------------------------------- */
void main(void)
{
    unsigned char count1 = 0;   /* press count for Switch 1 → Port 0 */
    unsigned char count2 = 0;   /* press count for Switch 2 → Port 1 */

    /* Initialise output ports (all LEDs off) */
    P0 = 0x00;
    P1 = 0x00;

    /*
     * Configure Port 2 for input.
     * Writing 0xFF enables the internal weak pull-ups on the 8051 quasi-
     * bidirectional pins, so unconnected / released switches read as logic 1.
     */
    P2 = 0xFF;

    while (1)
    {
        /* ---- Switch 1 on P2.0 ---- */
        if (SW1 == 0)                   /* active-low: pressed = 0 */
        {
            debounce_delay();           /* wait for contact to settle  */

            if (SW1 == 0)              /* confirm still pressed        */
            {
                count1++;
                P0 = count1;           /* show binary count on Port 0 */

                while (SW1 == 0);      /* wait for release             */
                debounce_delay();      /* debounce on release          */
            }
        }

        /* ---- Switch 2 on P2.1 ---- */
        if (SW2 == 0)                   /* active-low: pressed = 0 */
        {
            debounce_delay();

            if (SW2 == 0)
            {
                count2++;
                P1 = count2;           /* show binary count on Port 1 */

                while (SW2 == 0);
                debounce_delay();
            }
        }
    }
}
