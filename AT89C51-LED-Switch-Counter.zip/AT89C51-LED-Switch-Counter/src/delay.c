/**
 * @file    delay.c
 * @brief   Software debounce delay implementation.
 */

#include "led_switch.h"

void debounce_delay(void)
{
    unsigned int i;
    for (i = 0; i < DEBOUNCE_COUNT; i++)
    {
        /* intentionally empty — burns CPU cycles for ~20 ms @ 11.0592 MHz */
    }
}
