# AT89C51 — Dual Switch Press Counter with Binary LED Display

A bare-metal embedded C project targeting the **AT89C51** (8051-family) microcontroller.  
Two independent push-buttons each maintain their own press counter, displayed live as an 8-bit binary pattern on dedicated LED ports.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Hardware](#hardware)
  - [Pin Mapping](#pin-mapping)
  - [Bill of Materials](#bill-of-materials)
  - [Circuit Notes](#circuit-notes)
- [Software](#software)
  - [Repository Structure](#repository-structure)
  - [How It Works](#how-it-works)
  - [Debounce Strategy](#debounce-strategy)
- [Building with Keil µVision](#building-with-keil-µvision)
- [Simulation in Proteus](#simulation-in-proteus)
- [Expected Results](#expected-results)
- [Applications](#applications)

---

## Project Overview

| Item | Detail |
|------|--------|
| **MCU** | AT89C51 (Atmel 8051, 4 KB Flash) |
| **Clock** | 11.0592 MHz crystal |
| **Supply** | +5 V DC |
| **Toolchain** | Keil µVision 5 (C51 compiler) |
| **Simulation** | Proteus 8 Professional |
| **Language** | Embedded C (C51) |

**Objective:** Count independent button presses and reflect each count as a binary number on 8 LEDs — without any external display driver or RTOS.

---

## Hardware

### Pin Mapping

```
AT89C51
┌──────────────────────────────┐
│  P0.0 – P0.7  ──►  LED 1–8  │  (Switch 1 count — LSB at P0.0)
│  P1.0 – P1.7  ──►  LED 9–16 │  (Switch 2 count — LSB at P1.0)
│  P2.0          ◄── Switch 1  │  (active-low, pull-up via 0xFF init)
│  P2.1          ◄── Switch 2  │  (active-low, pull-up via 0xFF init)
└──────────────────────────────┘
```

> **Common-cathode wiring:** All LED cathodes share a common GND rail.  
> A logic **1** on a port pin sources current through the 330 Ω resistor and lights the LED.

### Bill of Materials

| Component | Value / Part | Qty | Purpose |
|-----------|-------------|-----|---------|
| Microcontroller | AT89C51 | 1 | Main processing unit |
| LEDs (common cathode) | Any 5 mm, ~20 mA | 16 | Output indicators |
| Current-limiting resistors | 330 Ω | 16 | Protect LEDs |
| Pull-up resistor array | 10 kΩ | 1 | Port 0 pull-up (quasi-bidir.) |
| Push-buttons | SPST, NO | 2 | Switch inputs |
| Crystal oscillator | 11.0592 MHz | 1 | System clock |
| Load capacitors | 22 pF | 2 | Crystal stabilisation |
| Reset capacitor | 10 µF | 1 | Power-on reset |
| Reset resistor | 10 kΩ | 1 | Power-on reset |
| Power supply | +5 V DC | 1 | System power |

### Circuit Notes

1. **Port 0 pull-ups** — Port 0 on the 8051 is an open-drain port and lacks internal pull-ups. A 10 kΩ resistor array tied to VCC is required for it to output a proper logic high.
2. **Reset circuit** — The 10 µF capacitor in series with the 10 kΩ resistor on the RST pin holds the chip in reset for ~100 ms at power-on, ensuring a clean start.
3. **Switch wiring** — Each switch connects the respective Port 2 pin to GND. When released, the 8051's internal quasi-bidirectional pull-up holds the line high.

---

## Software

### Repository Structure

```
AT89C51-LED-Switch-Counter/
├── src/
│   ├── main.c          # Application logic — polling loop, counter updates
│   └── delay.c         # Software debounce delay implementation
├── include/
│   └── led_switch.h    # Pin aliases, DEBOUNCE_COUNT, function prototype
├── simulation/
│   └── LED_Switch_Counter.uvproj   # Keil µVision project file
├── docs/
│   └── circuit_description.md      # Detailed hardware notes
├── .gitignore
└── README.md
```

### How It Works

```
Power-on
   │
   ▼
Initialise: P0=0x00, P1=0x00, P2=0xFF
   │
   ▼
┌──────────────── polling loop ─────────────────┐
│                                               │
│  P2.0 == 0? ──Yes──► debounce ──► count1++   │
│                                   P0 = count1 │
│                                   wait release│
│                                               │
│  P2.1 == 0? ──Yes──► debounce ──► count2++   │
│                                   P1 = count2 │
│                                   wait release│
└───────────────────────────────────────────────┘
```

- Counters are 8-bit (`unsigned char`), so they naturally wrap 255 → 0.
- The count is written directly to the port register — no lookup table needed because the binary value *is* the LED pattern.

### Debounce Strategy

Mechanical switches produce contact bounce lasting up to ~10 ms. Two debounce delays are applied per press cycle:

1. **Press debounce** — after the falling edge is detected, wait ~20 ms, then re-confirm the pin is still low before counting.
2. **Release debounce** — after the pin returns high, wait another ~20 ms before accepting the next press.

The `DEBOUNCE_COUNT` constant in `led_switch.h` can be tuned for different clocks or switch characteristics without touching the main logic.

---

## Building with Keil µVision

1. Open **Keil µVision 5**.
2. Go to **Project → Open Project** and navigate to `simulation/LED_Switch_Counter.uvproj`.
3. Verify the include path points to `../include` (already set in the project file).
4. Press **F7** (Build) — the HEX file is written to `simulation/output/LED_Switch_Counter.hex`.
5. Check the Build Output panel; warnings about unused variables in the delay loop are expected and harmless.

---

## Simulation in Proteus

1. Open **Proteus 8 Professional**.
2. Place an **AT89C51**, double-click it, and load `simulation/output/LED_Switch_Counter.hex` into the **Program File** field.
3. Wire the circuit according to the [Pin Mapping](#pin-mapping) and BOM above.
4. Press the **Play** button.
5. Click Switch 1 (P2.0) — the Port 0 LEDs will increment in binary.  
   Click Switch 2 (P2.1) — the Port 1 LEDs will increment independently.

---

## Expected Results

| Switch Event | LED Port | Binary Pattern |
|-------------|----------|---------------|
| SW1 pressed once | P0 | `0000 0001` |
| SW1 pressed twice | P0 | `0000 0010` |
| SW1 pressed three times | P0 | `0000 0011` |
| SW2 pressed once | P1 | `0000 0001` |
| SW2 pressed twice | P1 | `0000 0010` |
| Both counters active | P0 & P1 | Independent values |

LEDs remain lit between presses — the last count is always displayed until the next press changes it.

---

## Applications

- Digital event / frequency counters
- Switch-based control systems and user interfaces  
- Teaching aid for digital I/O, port programming, and binary representation  
- Starting point for more complex 8051 interrupt-driven designs
